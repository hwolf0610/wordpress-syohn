# wp-plugin-CRUD
a wordpress plugin for the CRUD
